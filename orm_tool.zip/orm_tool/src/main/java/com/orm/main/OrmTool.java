package com.orm.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class OrmTool {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/orm","root","root");
		Statement statement = connection.createStatement();
		
		String query;
		
		// query to insert data into db
		
		
		/*
		 * query = "insert into employee values('Ashesh Kumar',36)"; int count =
		 * statement.executeUpdate(query); System.out.println("rows affected: "+count);
		 */
		 
		 
		
		
		// query to retrieve data from db
		
		  query = "select * from employee";
		  
		  ResultSet resultSet = statement.executeQuery(query);
		  
		  while(resultSet.next()) {
		  System.out.println(resultSet.getString(1)+" "+resultSet.getInt(2)); }
		 
		
		// query to update data in the database
		/*
		 * query = "update employee set age = 32 where name = 'Ashesh Kumar'"; int count
		 * = statement.executeUpdate(query);
		 * System.out.println("rows affected: "+count);
		 * 
		 */
		
		// Query to delete data from database
		/*
		 * query = "delete from employee where age = 32"; int count =
		 * statement.executeUpdate(query);
		 * System.out.println("Number of records deleted: "+count);
		 */
		
		
		statement.close();
		connection.close();
		
		
	}

}
